package camt.se331.shoppingcart.entity;

import org.junit.Test;
import static junitparams.JUnitParamsRunner.$;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;

/**
 * Created by Dto on 2/22/2015.
 */
public class ProductTest {
    @Test
    public void testGetNetPrice(){

    }

    @Test
    public void testGetVat(){

    }




}
